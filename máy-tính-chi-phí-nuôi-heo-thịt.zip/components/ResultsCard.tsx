import React, { useState, useRef, useMemo } from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { AppState, CalculationResult } from '../types';
import { ChartIcon, ShareIcon, DownloadIcon } from './Icons';

interface ResultsCardProps {
  results: CalculationResult;
  getStateToShare: () => AppState;
}

const ResultsCard: React.FC<ResultsCardProps> = ({ results, getStateToShare }) => {
  const [shareStatus, setShareStatus] = useState<'idle' | 'copied'>('idle');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleShare = () => {
    const stateToShare = getStateToShare();
    const jsonState = JSON.stringify(stateToShare);
    const base64State = btoa(jsonState);
    const shareUrl = `${window.location.origin}${window.location.pathname}#${base64State}`;
    
    navigator.clipboard.writeText(shareUrl).then(() => {
      setShareStatus('copied');
      setTimeout(() => setShareStatus('idle'), 2000);
    }).catch(err => {
      console.error('Failed to copy link: ', err);
      alert('Không thể sao chép liên kết. Vui lòng sao chép thủ công.');
    });
  };

  const handleDownloadPdf = async () => {
    const html2canvas = (window as any).html2canvas;
    const jspdf = (window as any).jspdf;

    if (typeof html2canvas === 'undefined' || typeof jspdf === 'undefined') {
      alert("Lỗi: Không thể tải thư viện tạo PDF. Vui lòng kiểm tra kết nối mạng và thử lại. Nếu sự cố vẫn tiếp diễn, trình chặn quảng cáo có thể đang chặn các tập lệnh cần thiết.");
      return;
    }

    const elementToCapture = resultsRef.current;
    if (!elementToCapture) {
      alert("Không tìm thấy phần tử kết quả để xuất.");
      return;
    }

    setIsGeneratingPdf(true);
    try {
      const canvas = await html2canvas(elementToCapture, { scale: 2, backgroundColor: '#ffffff' });
      const imgData = canvas.toDataURL('image/png');
      
      const { jsPDF } = jspdf;
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const canvasAspectRatio = canvas.width / canvas.height;
      
      const margin = 15;
      let imgWidth = pdfWidth - margin * 2;
      let imgHeight = imgWidth / canvasAspectRatio;

      if (imgHeight > pdfHeight - margin * 2) {
        imgHeight = pdfHeight - margin * 2;
        imgWidth = imgHeight * canvasAspectRatio;
      }
      
      const x = (pdfWidth - imgWidth) / 2;
      const y = margin;

      pdf.addImage(imgData, 'PNG', x, y, imgWidth, imgHeight);
      pdf.save('pig-cost-calculation.pdf');

    } catch (error) {
      console.error("Lỗi khi tạo PDF:", error);
      alert("Đã xảy ra lỗi khi tạo tệp PDF.");
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const formatCurrency = (value: number) => {
    if (typeof value !== 'number' || isNaN(value)) return '0 VNĐ';
    const formattedValue = new Intl.NumberFormat('vi-VN').format(Math.round(value));
    return `${formattedValue} VNĐ`;
  };
  
  const formatNumber = (value: number, precision: number = 2) => {
    if (typeof value !== 'number' || isNaN(value)) return '0.00';
    return new Intl.NumberFormat('vi-VN', { minimumFractionDigits: precision, maximumFractionDigits: precision }).format(value);
  }

  const formatYAxis = (tickItem: number): string => {
    if (tickItem >= 1000000) return `${tickItem / 1000000}M`;
    if (tickItem >= 1000) return `${tickItem / 1000}k`;
    return String(tickItem);
  };

  const expectedScenario = results.profitScenarios.find(s => s.scenario.includes('Dự kiến'));
  const expectedProfit = expectedScenario?.profit ?? 0;
  const profitColor = expectedProfit >= 0 ? 'text-green-600' : 'text-red-600';

  const costData = [
    { name: 'Chi phí thức ăn', value: results.totalFeedCost },
    { name: 'Chi phí giống', value: results.geneticPrice },
    { name: 'Chi phí thuốc', value: results.medicineCost },
    { name: 'Chi phí quản lý', value: results.managementCost },
  ].filter(item => item.value > 0);

  const PIE_COLORS = ['#10B981', '#3B82F6', '#F97316', '#8B5CF6'];

  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    if (percent < 0.05) return null; // Don't render label for small slices
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor={x > cx ? 'start' : 'end'}
        dominantBaseline="central"
        fontWeight="bold"
        fontSize="14"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  const { stackedBarData, uniqueFeeds, feedColors } = useMemo(() => {
    const uniqueFeeds = [...new Set(results.stageCosts.map(sc => sc.feed))];
    const feedColors: { [key: string]: string } = {};
    const BAR_COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#6366F1', '#EC4899'];
    uniqueFeeds.forEach((feed, index) => {
      feedColors[feed] = BAR_COLORS[index % BAR_COLORS.length];
    });

    const groupedByStage = results.stageCosts.reduce<{ [key: string]: any }>((acc, current) => {
      if (!acc[current.name]) {
        acc[current.name] = { name: current.name };
      }
      acc[current.name][current.feed] = (acc[current.name][current.feed] || 0) + current.cost;
      return acc;
    }, {});

    const stackedBarData = Object.values(groupedByStage);
    return { stackedBarData, uniqueFeeds, feedColors };
  }, [results.stageCosts]);

  return (
    <div id="results-to-export" ref={resultsRef} className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <div className="flex flex-wrap items-center justify-between mb-4 border-b pb-2 gap-2">
        <div className="flex items-center">
          <ChartIcon className="w-6 h-6 text-green-600 mr-3" />
          <h2 className="text-2xl font-bold text-gray-700">Kết quả tính toán</h2>
        </div>
        <div className="flex items-center space-x-2">
           <button
            onClick={handleShare}
            className="flex items-center px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
          >
            <ShareIcon className="w-5 h-5 mr-2" />
            {shareStatus === 'copied' ? 'Đã sao chép!' : 'Chia sẻ'}
          </button>
           <button
            onClick={handleDownloadPdf}
            disabled={isGeneratingPdf}
            className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors disabled:bg-blue-300 disabled:cursor-not-allowed"
          >
            <DownloadIcon className="w-5 h-5 mr-2" />
            {isGeneratingPdf ? 'Đang tạo...' : 'Tải PDF'}
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gray-100 p-4 rounded-lg text-center md:col-span-2">
          <p className="text-sm font-medium text-gray-500">Lợi nhuận/con (Dự kiến)</p>
          <p className={`text-2xl font-bold ${profitColor}`}>{formatCurrency(expectedProfit)}</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg text-center">
          <p className="text-sm font-medium text-gray-500">Tổng chi phí</p>
          <p className="text-2xl font-bold text-gray-800">{formatCurrency(results.totalCost)}</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg text-center">
          <p className="text-sm font-medium text-gray-500">Số ngày nuôi dự kiến</p>
          <p className="text-2xl font-bold text-gray-800">{formatNumber(results.numberOfDays, 0)} ngày</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg text-center">
          <p className="text-sm font-medium text-gray-500">Chi phí/kg hơi</p>
          <p className="text-xl font-bold text-gray-800">{formatCurrency(results.costPerKgLiveWeight)}</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg text-center">
          <p className="text-sm font-medium text-gray-500">Giá cám/kg tăng trọng</p>
          <p className="text-xl font-bold text-gray-800">{formatCurrency(results.feedCostPerKgGain)}</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg text-center">
          <p className="text-sm font-medium text-gray-500">Tổng cám</p>
          <p className="text-xl font-bold text-gray-800">{formatNumber(results.totalFeedConsumed)} kg</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg text-center">
          {results.calculationMode === 'forecast' ? (
            <>
              <p className="text-sm font-medium text-gray-500">Tổng tăng trọng</p>
              <p className="text-xl font-bold text-gray-800">{formatNumber(results.totalWeightGain)} kg</p>
            </>
          ) : (
             <>
              <p className="text-sm font-medium text-gray-500">Trọng lượng dự kiến</p>
              <p className="text-xl font-bold text-gray-800">{formatNumber(results.projectedFinalWeight || 0)} kg</p>
            </>
          )}
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Phân tích Tài chính Chi tiết</h3>
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
          <div className="lg:col-span-2">
            <h4 className="text-lg font-semibold text-gray-600 mb-2 text-center">Phân bổ Chi phí</h4>
            <div style={{ width: '100%', height: 220 }}>
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={costData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={renderCustomizedLabel}
                    innerRadius={40}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {costData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-full mt-4 space-y-2">
              {costData.map((entry, index) => {
                const percentage = (entry.value / results.totalCost * 100).toFixed(1);
                return (
                  <div key={entry.name} className="flex justify-between items-center text-sm p-2 rounded-md bg-gray-50">
                    <div className="flex items-center">
                      <span className="w-3 h-3 rounded-full mr-3 flex-shrink-0" style={{ backgroundColor: PIE_COLORS[index % PIE_COLORS.length] }}></span>
                      <span className="text-gray-600">{entry.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-semibold text-gray-800">{formatCurrency(entry.value)}</span>
                      <span className="text-gray-500 ml-2 text-xs">({percentage}%)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="lg:col-span-3">
             <h4 className="text-lg font-semibold text-gray-600 mb-4 text-center">Kịch bản Lợi nhuận theo Giá thị trường</h4>
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
              {results.profitScenarios.map((scenario, index) => {
                const salesWeight = scenario.hogPrice > 0 ? scenario.revenue / scenario.hogPrice : 0;
                const isExpected = scenario.scenario.includes('Dự kiến');
                const profitColor = scenario.profit >= 0 ? 'text-green-600' : 'text-red-600';
                const borderColor = isExpected ? 'border-green-400' : 'border-gray-200';
                const bgColor = isExpected ? 'bg-green-50' : 'bg-white';
                const titleColor = isExpected ? 'text-green-800' : 'text-gray-700';

                return (
                  <div key={index} className={`p-4 border-2 ${borderColor} ${bgColor} rounded-lg shadow-sm flex flex-col`}>
                    <h5 className={`font-bold text-center mb-4 text-lg ${titleColor}`}>{scenario.scenario}</h5>
                    <div className="space-y-2 text-sm flex-grow font-mono">
                      <div className="flex justify-between items-baseline">
                        <span className="text-gray-600">Doanh thu</span>
                        <span className="font-semibold text-gray-800 text-base">{formatCurrency(scenario.revenue)}</span>
                      </div>
                      <p className="text-xs text-gray-500 text-right pb-2">
                        {formatNumber(salesWeight)} kg × {formatCurrency(scenario.hogPrice).replace(' VNĐ', '')}/kg
                      </p>
                      
                      <div className="flex justify-between items-baseline">
                        <span className="text-gray-600">Tổng chi phí</span>
                        <span className="font-semibold text-gray-800 text-base">- {formatCurrency(results.totalCost)}</span>
                      </div>
                    </div>
                    
                    <hr className={`my-3 border-dashed ${isExpected ? 'border-green-300' : 'border-gray-200'}`} />

                    <div className="flex justify-between items-center">
                      <span className="font-bold text-gray-700 text-base">Lợi nhuận</span>
                      <span className={`font-bold text-xl ${profitColor}`}>{formatCurrency(scenario.profit)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Chi tiết Chi phí Thức ăn theo Giai đoạn</h3>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <BarChart
              data={stackedBarData}
              margin={{ top: 20, right: 20, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis
                tickFormatter={formatYAxis}
                width={80}
                tick={{ fontSize: 12 }}
                domain={[0, 'dataMax + 100000']}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.9)',
                  borderRadius: '0.5rem',
                  border: '1px solid #e2e8f0',
                }}
                formatter={(value: number, name: string) => [formatCurrency(value), name]}
                labelFormatter={(label: string) => `Giai đoạn: ${label}`}
              />
              <Legend />
              {uniqueFeeds.map(feed => (
                <Bar key={feed} dataKey={feed} stackId="a" fill={feedColors[feed]} name={feed} radius={[4, 4, 0, 0]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="overflow-x-auto mt-4">
          <table className="min-w-full bg-white border border-gray-200 rounded-lg">
            <thead className="bg-gray-50">
              <tr className="text-left text-sm font-semibold text-gray-600">
                <th className="p-3">Giai đoạn</th>
                <th className="p-3">Mã sản phẩm</th>
                <th className="p-3 text-right">Lượng cám (kg)</th>
                <th className="p-3 text-right">Giá/Bao</th>
                <th className="p-3 text-right">Tổng Chi phí</th>
              </tr>
            </thead>
            <tbody>
              {results.stageCosts.filter(stage => stage.cost > 0).map((stage, index) => (
                <tr key={index} className="border-b border-gray-200 last:border-b-0 hover:bg-gray-50">
                  <td className="p-3 font-medium text-gray-800">{stage.name}</td>
                  <td className="p-3 text-gray-600">{stage.feed}</td>
                  <td className="p-3 text-right font-mono">{formatNumber(stage.feedKg)}</td>
                  <td className="p-3 text-right font-mono">{formatCurrency(stage.pricePerBag)}</td>
                  <td className="p-3 text-right font-mono font-semibold text-gray-800">{formatCurrency(stage.cost)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ResultsCard;