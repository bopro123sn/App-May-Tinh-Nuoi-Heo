import React from 'react';
import { Stage, Feed } from '../types';

interface FeedStageCardProps {
  stage: Stage;
  onChange: (updatedStage: Stage) => void;
}

const FeedStageCard: React.FC<FeedStageCardProps> = ({ stage, onChange }) => {
  const formatNumber = (value: number) => {
    if (isNaN(value)) return '';
    return new Intl.NumberFormat('en-US').format(value);
  };

  const handleFeedChange = (feedId: string, updatedValues: Partial<Feed>) => {
    const updatedFeeds = stage.feeds.map(feed => 
      feed.id === feedId ? { ...feed, ...updatedValues } : feed
    );
    onChange({ ...stage, feeds: updatedFeeds });
  };
  
  const handleAddFeed = () => {
    const newFeed: Feed = {
      id: crypto.randomUUID(),
      productCode: '',
      pricePerBag: 0,
      fcr: 0,
      bagsConsumed: 0
    };
    onChange({ ...stage, feeds: [...stage.feeds, newFeed] });
  };

  const handleRemoveFeed = (feedId: string) => {
    const updatedFeeds = stage.feeds.filter(feed => feed.id !== feedId);
    onChange({ ...stage, feeds: updatedFeeds });
  };

  return (
    <div className="p-4 border border-gray-200 rounded-lg bg-gray-50">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-bold text-lg text-gray-700">{stage.name} <span className="text-sm font-normal text-gray-500">({stage.startWeight} - {stage.endWeight} kg)</span></h3>
        <button
          onClick={handleAddFeed}
          className="px-3 py-1 text-sm bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors"
        >
          Thêm sản phẩm
        </button>
      </div>
      
      <div className="space-y-3">
        {stage.feeds.map((feed, index) => (
          <div key={feed.id} className="p-3 border rounded-md bg-white relative">
            {stage.feeds.length > 1 && (
              <button 
                onClick={() => handleRemoveFeed(feed.id)}
                className="absolute top-2 right-2 text-gray-400 hover:text-red-500"
                aria-label="Remove feed"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
            <div className="grid grid-cols-2 md:grid-cols-2 gap-4 mt-2">
              <div>
                <label htmlFor={`${feed.id}-productCode`} className="block text-xs font-medium text-gray-600 mb-1">
                  Mã sản phẩm
                </label>
                <input
                  id={`${feed.id}-productCode`}
                  type="text"
                  value={feed.productCode}
                  onChange={(e) => handleFeedChange(feed.id, { productCode: e.target.value })}
                  className="w-full px-2 py-1.5 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-green-500 transition"
                />
              </div>
              <div>
                <label htmlFor={`${feed.id}-price`} className="block text-xs font-medium text-gray-600 mb-1">
                  Giá/Bao (VNĐ)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  id={`${feed.id}-price`}
                  value={formatNumber(feed.pricePerBag)}
                  onChange={(e) => {
                    const numericValue = parseInt(e.target.value.replace(/[^0-9]/g, '')) || 0;
                    handleFeedChange(feed.id, { pricePerBag: numericValue });
                  }}
                  className="w-full px-2 py-1.5 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-green-500 transition"
                />
              </div>
              <div>
                <label htmlFor={`${feed.id}-fcr`} className="block text-xs font-medium text-gray-600 mb-1">
                  FCR (ước tính)
                </label>
                <input
                  type="number"
                  id={`${feed.id}-fcr`}
                  value={feed.fcr}
                  onChange={(e) => handleFeedChange(feed.id, { fcr: parseFloat(e.target.value) || 0 })}
                  className="w-full px-2 py-1.5 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-green-500 transition"
                  step="0.01"
                  min="0"
                />
              </div>
              <div>
                <label htmlFor={`${feed.id}-bags`} className="block text-xs font-medium text-gray-600 mb-1">
                  Số bao (thực tế)
                </label>
                <input
                  type="number"
                  id={`${feed.id}-bags`}
                  value={feed.bagsConsumed}
                  onChange={(e) => handleFeedChange(feed.id, { bagsConsumed: parseFloat(e.target.value) || 0 })}
                  className="w-full px-2 py-1.5 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-1 focus:ring-green-500 transition"
                  step="0.1"
                  min="0"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
      <p className="text-xs text-gray-500 mt-2">
        Nhập 'Số bao' để tính toán theo thực tế. Nếu để trống, tính toán sẽ dựa trên FCR ước tính.
      </p>
    </div>
  );
};

export default FeedStageCard;
