
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white mt-8 py-4 border-t">
      <div className="container mx-auto px-4 md:px-6 text-center text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} Máy tính chi phí nuôi heo thịt. Đã đăng ký bản quyền.</p>
        <p className="mt-1">Xây dựng với React, TypeScript, và Tailwind CSS.</p>
      </div>
    </footer>
  );
};

export default Footer;
