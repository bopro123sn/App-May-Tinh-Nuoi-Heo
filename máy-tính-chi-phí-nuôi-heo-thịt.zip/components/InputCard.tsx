import React from 'react';
import { WeightIcon } from './Icons';

interface InputCardProps {
  startWeight: number;
  setStartWeight: (weight: number) => void;
  targetWeight: number;
  setTargetWeight: (weight: number) => void;
  geneticPrice: number;
  setGeneticPrice: (price: number) => void;
  medicineCost: number;
  setMedicineCost: (cost: number) => void;
  managementCost: number;
  setManagementCost: (cost: number) => void;
  forecastedHogPrice: number;
  setForecastedHogPrice: (price: number) => void;
}

const InputCard: React.FC<InputCardProps> = ({ 
  startWeight, setStartWeight, 
  targetWeight, setTargetWeight,
  geneticPrice, setGeneticPrice,
  medicineCost, setMedicineCost,
  managementCost, setManagementCost,
  forecastedHogPrice, setForecastedHogPrice,
 }) => {

  const handleNumericChange = (setter: (value: number) => void) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const numericValue = parseInt(e.target.value.replace(/[^0-9]/g, '')) || 0;
    setter(numericValue);
  };

  const formatNumber = (value: number) => {
    if (isNaN(value)) return '';
    return new Intl.NumberFormat('en-US').format(value);
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <div className="flex items-center mb-4 border-b pb-2">
        <WeightIcon className="w-6 h-6 text-green-600 mr-3" />
        <h2 className="text-2xl font-bold text-gray-700">Đầu vào</h2>
      </div>
      <div className="space-y-4">
        <div>
          <label htmlFor="startWeight" className="block text-sm font-medium text-gray-600 mb-1">
            Trọng lượng bắt đầu (kg)
          </label>
          <input
            id="startWeight"
            type="number"
            value={startWeight}
            onChange={(e) => setStartWeight(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
            min="0"
          />
        </div>
        <div>
          <label htmlFor="targetWeight" className="block text-sm font-medium text-gray-600 mb-1">
            Trọng lượng xuất chuồng (kg)
          </label>
          <input
            id="targetWeight"
            type="number"
            value={targetWeight}
            onChange={(e) => setTargetWeight(Math.max(0, parseInt(e.target.value) || 0))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
            min={startWeight}
          />
        </div>
        <div>
          <label htmlFor="forecastedHogPrice" className="block text-sm font-medium text-gray-600 mb-1">
            Giá heo hơi dự kiến (VNĐ/kg)
          </label>
          <input
            id="forecastedHogPrice"
            type="text"
            inputMode="numeric"
            value={formatNumber(forecastedHogPrice)}
            onChange={handleNumericChange(setForecastedHogPrice)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
          />
        </div>
      </div>

      <hr className="my-6 border-gray-200" />
      
      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Chi phí khác</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="geneticPrice" className="block text-sm font-medium text-gray-600 mb-1">
              Giá heo giống (VNĐ/con)
            </label>
            <input
              id="geneticPrice"
              type="text"
              inputMode="numeric"
              value={formatNumber(geneticPrice)}
              onChange={handleNumericChange(setGeneticPrice)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
            />
          </div>
          <div>
            <label htmlFor="medicineCost" className="block text-sm font-medium text-gray-600 mb-1">
              Chi phí thuốc (VNĐ/con)
            </label>
            <input
              id="medicineCost"
              type="text"
              inputMode="numeric"
              value={formatNumber(medicineCost)}
              onChange={handleNumericChange(setMedicineCost)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
            />
          </div>
          <div>
            <label htmlFor="managementCost" className="block text-sm font-medium text-gray-600 mb-1">
              Chi phí quản lý (VNĐ/con)
            </label>
            <input
              id="managementCost"
              type="text"
              inputMode="numeric"
              value={formatNumber(managementCost)}
              onChange={handleNumericChange(setManagementCost)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default InputCard;